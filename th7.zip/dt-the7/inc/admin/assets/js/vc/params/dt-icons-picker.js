(function($) {
	$('.of-icons_picker-controls').each(function() {
		window.The7Options.iconsPicker(this);
	});
})(jQuery);