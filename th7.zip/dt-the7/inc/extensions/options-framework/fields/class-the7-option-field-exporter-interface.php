<?php

defined( 'ABSPATH' ) || exit;

interface The7_Option_Field_Exporter_Interface {
	public function with_settings( $settings );
}